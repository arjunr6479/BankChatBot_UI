// import { ComponentFixture, TestBed } from '@angular/core/testing';

// import { ReportFraudComponent } from './report-fraud.component';

// describe('ReportFraudComponent', () => {
//   let component: ReportFraudComponent;
//   let fixture: ComponentFixture<ReportFraudComponent>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       declarations: [ ReportFraudComponent ]
//     })
//     .compileComponents();

//     fixture = TestBed.createComponent(ReportFraudComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
// function expect(component: ReportFraudComponent) {
//   throw new Error('Function not implemented.');
// }

