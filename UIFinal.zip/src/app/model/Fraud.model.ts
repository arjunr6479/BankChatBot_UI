export class Fraud{
    constructor(
     public Email?: string,
     public FraudType?: string,
     public FraudAmount?: number,
     public FraudDate?: Date,
     public Details?:string
 
 
    )
    {
 
    }
 }