export class Complain
{
    constructor(
        public ComplainId?: number,
        public Name?: string,
        public Email?: string,
        public ComplaintDate?: Date,
        public Subject?: string,
        public Cmplain?:string
    ){}
}